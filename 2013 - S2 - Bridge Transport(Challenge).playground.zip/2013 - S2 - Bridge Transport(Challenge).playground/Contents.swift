import UIKit


func convertFilesToIntArray (fileName: String, fileExtention: String) -> [Int]{
    let one = Bundle.main.url(forResource: fileName, withExtension: fileExtention)
    var fileStringArray = (try! String(contentsOf: one!, encoding: String.Encoding.utf8)).components(separatedBy: "\n")
    fileStringArray.removeLast()
    // can remove the for looop if there are no spaces in the numbers in the file.
    let finalFile = fileStringArray.map({Int ($0)!})
    return finalFile
}

let fileOne = convertFilesToIntArray(fileName: "s2.1", fileExtention: ".in")
let fileTwo = convertFilesToIntArray(fileName: "s2.2", fileExtention: ".in")
let fileThree = convertFilesToIntArray(fileName: "s2.3", fileExtention: ".in")
let fileFour = convertFilesToIntArray(fileName: "s2.4", fileExtention: ".in")
let fileFive = convertFilesToIntArray(fileName: "s2.5", fileExtention: ".in")
let fileSeven = convertFilesToIntArray(fileName: "s2.7", fileExtention: ".in")
let fileEight = convertFilesToIntArray(fileName: "s2.8", fileExtention: ".in")
//let fileNine = convertFilesToIntArray(fileName: "s2.9", fileExtention: ".in")
//let fileTen = convertFilesToIntArray(fileName: "s2.10", fileExtention: ".in")
//let fileEleven = convertFilesToIntArray(fileName: "s2.11", fileExtention: ".in")

/*
 Problem Description:
 A train of railway cars attempts to cross a bridge. The length of each car is 10m but their weights might be different. The bridge is 40m long (thus can hold 4 train cars at one time). The bridge will crack if the total weight of the cars on it at one time is greater than a certain weight. The cars are numbered starting at 1, going up to N, and they cross the bridge in that order (i.e., 1 immediately followed by 2, which is immediately followed by 3, and so on). What is the largest number T of railway cars such that the train of cars 1...T (in order) can cross the bridge?

 Input Specification:
 An array with integers. The first number is the maximum weight W (1 ≤ W ≤ 100000) that the bridge can hold at any particular time. The second number is the number N (1 ≤ N ≤ 100000) which is the number of railway cars that we wish to move across the bridge. On each of the next N lines of input, there will be a positive integer wi (1 ≤ i ≤ N, 1 ≤ wi ≤ 100000) which represents the weight of the ith railway car in the sequence.
 
 Output Specification:
 Your output should be a non-negative integer representing the maximum number of railway cars that can be brought across the bridge in the order specified.
 
 Sample Input 1:
 [100, 6, 50, 30, 10, 10, 40, 50]
 
 Output for Sample Input 1:
 5
 
 */





